//
//  AllGroupCell.swift
//  DZ_ANDREEVa
//
//  Created by Юлия Андреева on 15.11.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//

import UIKit

class AllGroupCell: UITableViewCell {
    
    @IBOutlet weak var nameGroup: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
