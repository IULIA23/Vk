//
//  ViewController.swift
//  Vk
//
//  Created by Юлия Андреева on 05.12.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

